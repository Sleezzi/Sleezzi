declare module "*.module.css";
/// <reference types="react-scripts" />
